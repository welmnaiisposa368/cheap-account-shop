#!/usr/bin/env bash

cd exampleSite
hugo serve --themesDir ../..
cd ..
